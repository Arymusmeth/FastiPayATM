const baseURL = "https://fastipay.replit.app";

async function registrar() {
  document.getElementById("status").innerText = "📤 Registrando...";
  const res = await fetch(\`\${baseURL}/api/registro\`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ nombre: "Cliente ATM", telefono: "5512345678" })
  });
  const data = await res.json();
  localStorage.setItem("usuarioId", data.id);
  document.getElementById("output").innerText = JSON.stringify(data, null, 2);
  document.getElementById("status").innerText = "✅ Registrado";
}

async function verSaldo() {
  const id = localStorage.getItem("usuarioId");
  if (!id) return alert("❗ Primero regístrate");
  document.getElementById("status").innerText = "🔍 Consultando saldo...";
  const res = await fetch(\`\${baseURL}/api/saldo/\${id}\`);
  const data = await res.json();
  document.getElementById("output").innerText = JSON.stringify(data, null, 2);
  document.getElementById("status").innerText = "✅ Saldo obtenido";
}

async function recargar() {
  const id = localStorage.getItem("usuarioId");
  if (!id) return alert("❗ Primero regístrate");
  document.getElementById("status").innerText = "💳 Recargando...";
  const res = await fetch(\`\${baseURL}/api/admin/recarga\`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-admin-token": "superadmin"
    },
    body: JSON.stringify({ id, cantidad: 150 })
  });
  const data = await res.json();
  document.getElementById("output").innerText = JSON.stringify(data, null, 2);
  document.getElementById("status").innerText = "✅ Recarga exitosa";
}
